import java.lang.Object;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Composite;

import java.awt.Frame;

import org.eclipse.swt.awt.SWT_AWT;

import java.awt.Panel;
import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.Window;

import javax.sql.ConnectionEvent;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;

import org.eclipse.swt.widgets.Combo;
import org.eclipse.core.internal.registry.Contribution;
import org.eclipse.jface.viewers.ComboViewer;
import org.eclipse.swt.widgets.TrayItem;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.ArmEvent;
import org.eclipse.swt.events.ArmListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.List;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.jface.text.TextViewer;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.custom.ViewForm;
import org.eclipse.swt.custom.CBanner;
import org.eclipse.swt.custom.SashForm;

import swing2swt.layout.BoxLayout;

import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.Table;
import org.eclipse.jface.layout.TableColumnLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.Depart;
import org.eclipse.wb.swt.DischargeReadiness;
import org.eclipse.wb.swt.About;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.wb.swt.Scan;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.CoolBar;
import org.eclipse.swt.widgets.Decorations;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.awt.Desktop;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;

import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseAdapter;



public class Physi{
	public Physi() {
	}
	

	protected Shell shlEmrPhysicianView;
	private Text text_LoadPatients;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Physi window = new Physi();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		
				
				
		Display display = Display.getDefault();
		createContents();
		shlEmrPhysicianView.open();
		shlEmrPhysicianView.layout();
		while (!shlEmrPhysicianView.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlEmrPhysicianView = new Shell();
		shlEmrPhysicianView.setSize(1897, 1046);
		shlEmrPhysicianView.setText("EMR Physician View");
		shlEmrPhysicianView.setLayout(null);
		
		Menu menu = new Menu(shlEmrPhysicianView, SWT.BAR);
		shlEmrPhysicianView.setMenuBar(menu);
		
		MenuItem mntmTask = new MenuItem(menu, SWT.CASCADE);
		mntmTask.setText("Task");
		
		Menu menu_1 = new Menu(mntmTask);
		mntmTask.setMenu(menu_1);
		
		MenuItem mntmPrint = new MenuItem(menu_1, SWT.NONE);
		mntmPrint.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
										PrinterJob job = PrinterJob.getPrinterJob();
										
										boolean ok = job.printDialog();
										if (ok) {
											try {
												job.print();
											} catch (PrinterException arg) {
											}
										}
									}
								});
		
		
		
		
		mntmPrint.setText("Print");

		MenuItem mntmScan = new MenuItem(menu_1, SWT.NONE);
		mntmScan.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				Scan nw = new Scan();
				nw.NewScreen();

			}
		});
		
		mntmScan.setText("Scan");
		
		
		
		MenuItem mntmExit = new MenuItem(menu_1, SWT.NONE);
		mntmExit.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
							 {
							 System.exit(0);
							 }
							 }	
						
					}
				);
		
		
		mntmExit.setText("Exit");
		
		MenuItem mntmChart = new MenuItem(menu, SWT.CASCADE);
		mntmChart.setText("Chart");
		
		Menu menu_4 = new Menu(mntmChart);
		mntmChart.setMenu(menu_4);
		
		MenuItem mntmOrder = new MenuItem(menu_4, SWT.NONE);
		
		mntmOrder.setText("Order");
		
		MenuItem mntmPrescription = new MenuItem(menu_4, SWT.NONE);
		mntmPrescription.setText("Prescription");
		
		MenuItem mntmInpatientSummary = new MenuItem(menu_4, SWT.NONE);
		mntmInpatientSummary.setText("Inpatient Summary");
		
		MenuItem mntmAmbulatorySummary = new MenuItem(menu_4, SWT.NONE);
		mntmAmbulatorySummary.setText("Ambulatory Summary");
		
		MenuItem mntmDischargeSummary = new MenuItem(menu_4, SWT.NONE);
		mntmDischargeSummary.setText("Discharge Summary");
		
		MenuItem mntmPhyicianNotes = new MenuItem(menu_4, SWT.NONE);
		mntmPhyicianNotes.setText("Phyician Notes");
		
		MenuItem mntmProblemdiagnosis = new MenuItem(menu_4, SWT.NONE);
		mntmProblemdiagnosis.setText("Problem/Diagnosis");
		
		MenuItem mntmImmunization = new MenuItem(menu_4, SWT.NONE);
		mntmImmunization.setText("Immunization");
		
		MenuItem mntmForms = new MenuItem(menu_4, SWT.NONE);
		mntmForms.setText("Forms");
		
		MenuItem mntmLinks = new MenuItem(menu, SWT.CASCADE);
		mntmLinks.setText("Links");
		
		Menu menu_5 = new Menu(mntmLinks);
		mntmLinks.setMenu(menu_5);
		
		MenuItem mntmAbout = new MenuItem(menu, SWT.CASCADE);
		mntmAbout.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
						About nw = new About();
						nw.NewScreen();	
			}
		});
		mntmAbout.setText("About");
		
		
		Button btnMedicalLibrary = new Button(shlEmrPhysicianView, SWT.NONE);
		btnMedicalLibrary.setBounds(10, 10, 114, 25);
		
		btnMedicalLibrary.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Desktop d = Desktop.getDesktop();
				try {
					d.browse(new URI("https://www.ncbi.nlm.nih.gov/pubmed/"));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (URISyntaxException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnMedicalLibrary.setText("Medical Library");
		
		Button btnDischargeReady = new Button(shlEmrPhysicianView, SWT.NONE);
		btnDischargeReady.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DischargeReadiness nw = new DischargeReadiness();
				nw.NewScreen();	
			}
		});
		btnDischargeReady.setBounds(130, 10, 144, 25);
		btnDischargeReady.setText("Discharge Readiness");
		
		Button btnCommunication = new Button(shlEmrPhysicianView, SWT.NONE);
		btnCommunication.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Desktop d = Desktop.getDesktop();
				try {
					d.browse(new URI("https://www.ipswitch.com/moveit-transfer"));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (URISyntaxException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnCommunication.setBounds(280, 10, 114, 25);
		btnCommunication.setText("Communication");
		
		Button btnCalculator = new Button(shlEmrPhysicianView, SWT.NONE);
		btnCalculator.setBounds(0, 777, 244, 120);
		btnCalculator.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Calc nw = new Calc();
				nw.NewScreen();	
			}
		});
		btnCalculator.setBounds(400, 10, 80, 25);
		btnCalculator.setText("Calculator");
		

		
		
		Button btnDepart = new Button(shlEmrPhysicianView, SWT.NONE);
		btnDepart.setBounds(486, 10, 89, 25);
		btnDepart.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Depart nw = new Depart();
				nw.NewScreen();
			}
		});
		btnDepart.setText("Depart");
		
		Button btnHippa = new Button(shlEmrPhysicianView, SWT.NONE);
		btnHippa.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
						Desktop d = Desktop.getDesktop();
						try {
							d.browse(new URI("https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html"));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (URISyntaxException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
				});
	
		btnHippa.setBounds(581, 10, 75, 25);
		btnHippa.setText("HIPPA");
		
		Label lblMenu = new Label(shlEmrPhysicianView, SWT.NONE);
		lblMenu.setBounds(10, 53, 65, 21);
		lblMenu.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.BOLD));
		lblMenu.setText("Menu");
		
		ViewForm viewForm_5 = new ViewForm(shlEmrPhysicianView, SWT.NONE);
		viewForm_5.setBounds(91, 100, 0, 0);
		
		Composite composite = new Composite(shlEmrPhysicianView, SWT.NONE);
		composite.setBounds(10, 80, 244, 897);
		
		Button btnNewButton_1 = new Button(composite, SWT.NONE);
		 btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Order nw = new Order();
				nw.NewScreen();
			}
		}); 
		
		
		btnNewButton_1.setBounds(0, 0, 244, 140);
		btnNewButton_1.setText("Orders");
		
		Button btnPrescriptions = new Button(composite, SWT.NONE);
		btnPrescriptions.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Prescription nw = new Prescription();
				nw.NewScreen();
		
			}
		});
		
		btnPrescriptions.setBounds(0, 135, 244, 140);
		btnPrescriptions.setText("Prescriptions");
		
		
		
		Button btnInpatientSummary = new Button(composite, SWT.NONE);
		btnInpatientSummary.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				InpatientSummary nw = new InpatientSummary();
				nw.NewScreen();
			}
		});
		btnInpatientSummary.setBounds(0, 272, 244, 140);
		btnInpatientSummary.setText("Inpatient Summary");
		
		Button btnAmbulatorySummary = new Button(composite, SWT.NONE);
		btnAmbulatorySummary.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				AmbulatorySummary nw = new AmbulatorySummary();
				nw.NewScreen();
			}
		});
		btnAmbulatorySummary.setBounds(0, 410, 244, 140);
		btnAmbulatorySummary.setText("Ambulatory Summary");
		
		Button btnDischargeSummary = new Button(composite, SWT.NONE);
		btnDischargeSummary.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DischargeSummary nw = new DischargeSummary();
				nw.NewScreen();
			}
		});
		btnDischargeSummary.setBounds(0, 536, 244, 140);
		btnDischargeSummary.setText("Discharge Summary");
		
		Button btnImmunization = new Button(composite, SWT.NONE);
		btnImmunization.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Immunization nw = new Immunization();
				nw.NewScreen();
			}
		});
		btnImmunization.setText("Immunization");
		btnImmunization.setBounds(0, 657, 244, 140);
		
		Button btnForms = new Button(composite, SWT.NONE);
		btnForms.setBounds(0, 777, 244, 120);
		btnForms.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Forms nw = new Forms();
				nw.NewScreen();
			}
		});
		btnForms.setText("Forms");
		
		// might decide to you this option later instead of doubleclicking 
		/*text_LoadPatients = new Text(shlEmrPhysicianView, SWT.BORDER);
		text_LoadPatients.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				Search nw = new Search();
				nw.NewScreen();
	
			}
		}); 
		text_LoadPatients.setToolTipText("");
		text_LoadPatients.setBounds(1774, 14, 76, 21);*/
		
		Button btnPatients = new Button(shlEmrPhysicianView, SWT.NONE);
		btnPatients.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Search nw = new Search();
				nw.NewScreen();
			}
		});
		
		btnPatients.setFont(SWTResourceManager.getFont("Segoe UI", 11, SWT.BOLD));
		btnPatients.setBounds(1606, 10, 166, 25);
		btnPatients.setText("Load Patients");

	}

	public Window getframe() {
		// TODO Auto-generated method stub
		return null;
	}
}
