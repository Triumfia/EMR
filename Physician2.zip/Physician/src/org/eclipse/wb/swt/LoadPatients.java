package org.eclipse.wb.swt;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JTabbedPane;
import javax.swing.JSplitPane;
import javax.swing.JLayeredPane;
import javax.swing.JDesktopPane;
import javax.swing.JToolBar;

//import org.eclipse.wb.swt.Order.Order;

import javax.swing.JSeparator;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JEditorPane;

public class LoadPatients {

	private JFrame frmPatients;

	/**
	 * Launch the application.
	 */
	public static void NewScreen()  {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoadPatients window = new LoadPatients();
					window.frmPatients.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoadPatients() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPatients = new JFrame();
		frmPatients.setTitle("Patients");
		frmPatients.setResizable(false);
		frmPatients.setBounds(100, 100, 1016, 708);
		frmPatients.getContentPane().setLayout(null);
		
		JLabel lblNewJgoodiesLabel = DefaultComponentFactory.getInstance().createLabel("MENU");
		lblNewJgoodiesLabel.setBounds(10, 51, 64, 23);
		lblNewJgoodiesLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		frmPatients.getContentPane().add(lblNewJgoodiesLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 85, 213, 573);
		frmPatients.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("Order");
	
			
		
		btnNewButton.setBounds(0, 0, 213, 82);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Presciption ");
		btnNewButton_1.setBounds(0, 83, 213, 82);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Inpatient Summary ");
		btnNewButton_2.setBounds(0, 165, 213, 82);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Ambulatory Summary ");
		btnNewButton_3.setBounds(0, 246, 213, 82);
		panel.add(btnNewButton_3);
		
		JButton btnDischargeSummary = new JButton("Discharge Summary");
		btnDischargeSummary.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnDischargeSummary.setBounds(0, 327, 213, 82);
		panel.add(btnDischargeSummary);
		
		JButton btnImmunization = new JButton("Immunization ");
		btnImmunization.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnImmunization.setBounds(0, 409, 213, 82);
		panel.add(btnImmunization);
		
		JButton btnForms = new JButton("Forms");
		btnForms.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnForms.setBounds(0, 491, 213, 82);
		panel.add(btnForms);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(233, 98, 677, 560);
		frmPatients.getContentPane().add(tabbedPane);
		
		JEditorPane PhysicianNotes = new JEditorPane();
		tabbedPane.addTab("Physician Notes", null, PhysicianNotes, null);
		JEditorPane VitalSigns = new JEditorPane();
		tabbedPane.addTab("Vital Signs", null, VitalSigns, null);
		JEditorPane PastVisit = new JEditorPane();
		tabbedPane.addTab("Past Visit", null, PastVisit, null);
		
		JButton btnSave = new JButton("SAVE");
		btnSave.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnSave.setBounds(852, 54, 89, 23);
		frmPatients.getContentPane().add(btnSave);
	
		
	}
}
