package org.eclipse.wb.swt;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Window.Type;

public class Depart {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void NewScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Depart window = new Depart();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Depart() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
	table = new JTable();
	JFrame frmDepartProccess = new JFrame();
	frmDepartProccess.setAutoRequestFocus(false);
	frmDepartProccess.setTitle("Depart Proccess ");
	frmDepartProccess.setResizable(false);
      final JTable table = new JTable();
       
     
      Object[] columns = {"Clinic Problem", "Date", "Clinical Dx", "Date"};
      final DefaultTableModel model = new DefaultTableModel();
      model.setColumnIdentifiers(columns);
      table.setModel(model);
     
      table.setBackground(Color.black);
      table.setForeground(Color.white);
      Font font = new Font("", 1, 22);
      table.setFont(font);
      table.setRowHeight(30);
     
       final JTextField textClinicProblem = new JTextField();
       textClinicProblem.setBounds(20, 220, 100, 25);
       final JTextField textFname = new JTextField();
       textFname.setBounds(20, 250, 100, 25);
       final JTextField textLname = new JTextField();
       textLname.setBounds(20, 280, 100, 25);
       final JTextField textDate1 = new JTextField();
       textDate1.setBounds(20, 310, 100, 25);
       final JTextField textAddress = new JTextField();

      JButton btnAdd = new JButton ("Add");
      btnAdd.setBounds(150, 220, 100, 25);
      JButton btnDelete = new JButton ("Delete");
      btnDelete.setBounds(150, 310, 100, 25);
      JButton btnUpdate = new JButton ("Update");
      btnUpdate.setBounds(150, 265, 100, 25);
      frmDepartProccess.getContentPane().setLayout(null);
     
      JScrollPane pane = new JScrollPane(table);
      pane.setBounds(0, 32, 880, 168);
     
      frmDepartProccess.getContentPane().add(pane);
     
      frmDepartProccess.getContentPane().add(textClinicProblem);
      frmDepartProccess.getContentPane().add(textFname);
      frmDepartProccess.getContentPane().add(textLname);
      frmDepartProccess.getContentPane().add(textDate1);
     
      frmDepartProccess.getContentPane().add(btnAdd);
      frmDepartProccess.getContentPane().add(btnDelete);
      frmDepartProccess.getContentPane().add(btnUpdate);
      
      JLabel lblProblem = new JLabel("Problem");
      lblProblem.setFont(new Font("Tahoma", Font.BOLD, 15));
      lblProblem.setBounds(192, 7, 139, 14);
      frmDepartProccess.getContentPane().add(lblProblem);
      
      JLabel lblDiagnosis = new JLabel("Diagnosis");
      lblDiagnosis.setFont(new Font("Tahoma", Font.BOLD, 15));
      lblDiagnosis.setBounds(632, 7, 73, 14);
      frmDepartProccess.getContentPane().add(lblDiagnosis);
      
      JButton btnSave = new JButton("SAVE");
      btnSave.setFont(new Font("Tahoma", Font.BOLD, 15));
      btnSave.setBounds(756, 311, 89, 23);
      frmDepartProccess.getContentPane().add(btnSave);
      
      final Object[] row = new Object[4]; 
      btnAdd.addActionListener(new ActionListener(){
  
           @SuppressWarnings("unused")
		public void actionPerformed1(ActionEvent e){
            
               row[0] = textClinicProblem.getText();
               row[1] = textFname.getText();
               row[2] = textLname.getText();
               row[3] = textDate1.getText();
          
            
               model.addRow(row);
           }

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}
       });
          
          
     btnDelete.addActionListener(new ActionListener(){
     
        
           public void actionPerformed(ActionEvent e) {
           
               int i = table.getSelectedRow();
               if(i >= 0){
                   model.removeRow(i);
                }
                else{
                   System.out.println("Delete Error");
                }
            }
       });

      table.addMouseListener(new MouseAdapter() {
      
     
      public void mouseClicked(MouseEvent e){
      
           int i = table.getSelectedRow();
           textClinicProblem.setText(model.getValueAt(i, 0).toString());
           textFname.setText(model.getValueAt(i, 1).toString());
           textLname.setText(model.getValueAt(i, 2).toString());
           textDate1.setText(model.getValueAt(i, 3).toString());
      
      }
      });
      
      
      btnUpdate.addActionListener(new ActionListener(){
      
	       
	        public void actionPerformed(ActionEvent e) {
	        
		        int i = table.getSelectedRow();
		        
		        if (i >= 0)
		        {
		          model.setValueAt(textClinicProblem.getText(), i, 0);
		          model.setValueAt(textFname.getText(), i, 1);
		          model.setValueAt(textLname.getText(), i, 2);
		          model.setValueAt(textDate1.getText(), i, 3);
		        }
		        
		        else{
		        	System.out.println("Update Error");
		        }
	        }
      });
      
      
      frmDepartProccess.setSize(900, 400);
      frmDepartProccess.setLocationRelativeTo(null);
      frmDepartProccess.setVisible(true); 
   }
}





